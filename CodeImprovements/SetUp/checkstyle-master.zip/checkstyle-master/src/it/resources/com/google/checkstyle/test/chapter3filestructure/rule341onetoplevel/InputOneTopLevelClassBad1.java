package com.google.checkstyle.test.chapter3filestructure.rule341onetoplevel;

class Foo {} //ok
enum FooEnum {} // warn 
